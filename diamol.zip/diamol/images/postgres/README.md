# STATUS: IN-PROGRESS

All Linux builds good. Windows build is custom, needs to be verified.

### Credits

The Linux version uses the [official Postgres image on Docker Hub](https://hub.docker.com/_/postgres?tab=description).

The Windows version is based on [stellirin/docker-postgres-windows](https://github.com/stellirin/docker-postgres-windows).